package com.example.squadre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SquadreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SquadreApplication.class, args);
	}

}
